<?php
	// Exit if accessed directly
	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}

	/**
        * @package datavice-wp-plugin
		* @version 0.1.0
		* Script that defines all helper included.
	*/

	include_once ( DV_PLUGIN_PATH . '/includes/helpers/html.php' );
	include_once ( DV_PLUGIN_PATH . '/includes/helpers/array.php' );