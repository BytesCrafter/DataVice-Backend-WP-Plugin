<?php
	// Exit if accessed directly
	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}

	/**
	 * @package datavice-wp-plugin
     * @version 0.1.0
     * This is where you provide all the constant config.
    */

    //Include source data for library fo config.
    include_once ( DV_PLUGIN_PATH . '/includes/libraries/configs.php' );
    include_once ( DV_PLUGIN_PATH . '/includes/libraries/address-config.php' );